import serial
import serial.tools.list_ports
import time
import threading


class SerialLogic:
    def __init__(self):
        self.port_pairs = {}
        self.stop_event = threading.Event()
        self.read_threads = []
        self.port_speeds = {}

    def get_port_speed(self, port):
        return self.port_speeds.get(port, 9600)

    def set_port_speed(self, port, baudrate):
        self.port_speeds[port] = baudrate

    def populate_ports(self):
        ports = serial.tools.list_ports.comports()
        self.ports_list = [port.device for port in ports]

        if len(self.ports_list) < 4:
            raise ValueError("Not enough COM ports available.")

        self.create_port_pairs()
        return self.ports_list

    def create_port_pairs(self):
        checked_ports = set()

        for i in range(len(self.ports_list)):
            port1 = self.ports_list[i]
            if port1 in checked_ports:
                continue

            for j in range(i + 1, len(self.ports_list)):
                port2 = self.ports_list[j]
                if port2 in checked_ports:
                    continue

                if self.test_connection(port1, port2):
                    self.port_pairs[port1] = port2
                    self.port_pairs[port2] = port1
                    checked_ports.add(port1)
                    checked_ports.add(port2)
                    print(f"Connection established: {port1} ~ {port2}")
                    break

    def test_connection(self, port1, port2):
        print(f"Testing the connection between {port1} and {port2}...")
        try:
            with serial.Serial(port1, self.get_port_speed(port1), timeout=1) as ser1, \
                    serial.Serial(port2, self.get_port_speed(port2), timeout=1) as ser2:
                time.sleep(2)
                test_message = "TEST"
                ser1.write(test_message.encode())
                time.sleep(1)

                if ser2.in_waiting > 0:
                    response = ser2.read(ser2.in_waiting).decode()
                    print(f"Received message: {response} from {port2}")
                    return response == test_message
                else:
                    print("No response from the port.")
                    return False
        except serial.SerialException as e:
            print(f"Error: {e}")
            return False

    def send_and_receive_message(self, send_port, receive_port, message):
        self.port_speeds[send_port] = self.get_port_speed(send_port)
        self.port_speeds[receive_port] = self.get_port_speed(receive_port)

        try:
            with serial.Serial(send_port, self.get_port_speed(send_port), timeout=1) as ser1, \
                    serial.Serial(receive_port, self.get_port_speed(receive_port), timeout=1) as ser2:
                time.sleep(1)
                ser1.write(message.encode())

                if ser2.in_waiting > 0:
                    response = ser2.read(ser2.in_waiting).decode()
                    print(f"Message received: {response}")
                    return response
                else:
                    print("No response from the port.")
                    return None
        except serial.SerialException as e:
            print(f"Error: {e}")
            return None

    def start_reading(self, connected_port):
        try:
            with serial.Serial(connected_port, self.get_port_speed(connected_port), timeout=1) as ser:
                while not self.stop_event.is_set():
                    if ser.in_waiting > 0:
                        response = ser.read(ser.in_waiting).decode()
                        print(f"Received: {response} from {connected_port}")
                        return response
                    time.sleep(0.1)
        except serial.SerialException as e:
            print(f"Error reading response: {e}")

    def start_read_thread(self, connected_port):
        self.stop_event.clear()
        read_thread = threading.Thread(target=self.start_reading, args=(connected_port,))
        read_thread.start()
        self.read_threads.append(read_thread)

    def stop_read_thread(self):
        self.stop_event.set()
        for thread in self.read_threads:
            thread.join()
        self.read_threads.clear()
