import tkinter as tk
from tkinter import scrolledtext, ttk, messagebox
from serial_logic import SerialLogic


class SerialInterfaceApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Serial Interface")
        self.logic = SerialLogic()

        self.setup_ui()
        self.populate_ports()

    def setup_ui(self):
        self.create_output_frame()
        self.create_port_selection_frame()
        self.create_controls_frame()
        self.create_status_frame()

    def create_output_frame(self):
        self.output_frame = tk.Frame(self.master)
        self.output_frame.pack(pady=10)

        self.left_output_frame = self.create_output_subframe(self.output_frame, "Output from the first port:")
        self.left_output_text = self.create_scrolled_text(self.left_output_frame)

        self.right_output_frame = self.create_output_subframe(self.output_frame, "Output from the second port:")
        self.right_output_text = self.create_scrolled_text(self.right_output_frame)

    def create_output_subframe(self, parent, label_text):
        frame = tk.Frame(parent)
        frame.pack(side=tk.LEFT, padx=10)
        label = tk.Label(frame, text=label_text)
        label.pack()
        return frame

    def create_scrolled_text(self, parent):
        text_widget = scrolledtext.ScrolledText(parent, width=40, height=10, state='disabled')
        text_widget.pack(padx=5, pady=5)
        return text_widget

    def create_port_selection_frame(self):
        self.port_frame = tk.Frame(self.master)
        self.port_frame.pack(pady=10, side=tk.LEFT, anchor="n")

        self.send_port_combobox, self.send_connected_port = self.create_port_subframe(
            self.port_frame, "Port of dispatch:", self.update_connected_send_port
        )
        self.read_port_combobox, self.read_connected_port = self.create_port_subframe(
            self.port_frame, "Reading port:     ", self.update_connected_read_port
        )

    def create_port_subframe(self, parent, label_text, bind_method):
        frame = tk.Frame(parent)
        frame.pack(pady=10, anchor="w")

        label = tk.Label(frame, text=label_text)
        label.pack(side=tk.LEFT, padx=5)

        combobox = ttk.Combobox(frame, width=10)
        combobox.pack(side=tk.LEFT, padx=5)
        combobox.bind("<<ComboboxSelected>>", bind_method)

        connected_port_label = tk.Label(frame, text="Associated port:")
        connected_port_label.pack(side=tk.LEFT, padx=5)

        connected_port = tk.Label(frame, text="")
        connected_port.pack(side=tk.LEFT, padx=5)

        return combobox, connected_port

    def create_controls_frame(self):
        self.controls_frame = tk.Frame(self.master)
        self.controls_frame.pack(pady=10, side=tk.RIGHT, anchor="n")

        self.speed_combobox_send = self.create_speed_frame("Speed of the first port:")
        self.input_entry_send = self.create_input_frame("Message for the first port:", self.send_message_first)

        self.speed_combobox_receive = self.create_speed_frame("Speed of the second port:")
        self.input_entry_receive = self.create_input_frame("Message for the second port:", self.send_message_second)

    def create_speed_frame(self, label_text):
        frame = tk.Frame(self.controls_frame)
        frame.pack(pady=10)

        label = tk.Label(frame, text=label_text)
        label.pack(side=tk.LEFT, padx=5)

        combobox = ttk.Combobox(frame, values=[9600, 14400, 19200, 38400, 57600, 115200], state='readonly', width=10)
        combobox.current(0)
        combobox.pack(side=tk.LEFT, padx=5)
        return combobox

    def create_input_frame(self, label_text, bind_method):
        frame = tk.Frame(self.controls_frame)
        frame.pack(pady=10)

        label = tk.Label(frame, text=label_text)
        label.pack(side=tk.LEFT, padx=5)

        entry = tk.Entry(frame, width=40)
        entry.pack(side=tk.LEFT, padx=5)
        entry.bind("<Return>", bind_method)
        return entry

    def create_status_frame(self):
        self.status_frame = tk.Frame(self.controls_frame)
        self.status_frame.pack(pady=10)

        self.send_port_status_label = tk.Label(self.status_frame, text="Send Port: -")
        self.send_port_status_label.pack(pady=5)

        self.receive_port_status_label = tk.Label(self.status_frame, text="Receive Port: -")
        self.receive_port_status_label.pack(pady=5)

        self.bytes_in_portion_label = tk.Label(self.status_frame, text="Bytes in portion: 0")
        self.bytes_in_portion_label.pack(pady=5)

    def start_reading_from_port(self, port, speed, output_text_widget):
        def update_output(data):
            output_text_widget.config(state='normal')
            output_text_widget.insert(tk.END, data)
            output_text_widget.config(state='disabled')

        self.logic.start_read_thread(port, speed, update_output)

    def update_status_window(self, send_port, receive_port, bytes_in_portion):
        self.send_port_status_label.config(text=f"Send Port: {send_port}")
        self.receive_port_status_label.config(text=f"Receive Port: {receive_port}")
        self.bytes_in_portion_label.config(text=f"Bytes in portion: {bytes_in_portion}")

    def populate_ports(self):
        try:
            ports = self.logic.populate_ports()
            self.send_port_combobox['values'] = ports
            self.read_port_combobox['values'] = ports

            if ports:
                self.send_port_combobox.current(0)
                self.read_port_combobox.current(1)

            self.update_connected_send_port()
            self.update_connected_read_port()
        except ValueError as e:
            messagebox.error("Error", str(e))

    def update_connected_send_port(self, event=None):
        selected_port = self.send_port_combobox.get()
        connected_port = self.get_connected_port(selected_port)
        self.send_connected_port.config(text=connected_port)
        self.update_read_ports()

    def update_connected_read_port(self, event=None):
        selected_port = self.read_port_combobox.get()
        connected_port = self.get_connected_port(selected_port)
        self.read_connected_port.config(text=connected_port)

    def update_read_ports(self):
        selected_send_port = self.send_port_combobox.get()
        connected_send_port = self.get_connected_port(selected_send_port)

        available_ports = [
            port for port in self.logic.ports_list
            if port != selected_send_port and port != connected_send_port
        ]

        self.read_port_combobox['values'] = available_ports
        if available_ports:
            self.read_port_combobox.current(0)
        else:
            self.read_port_combobox.set('')

    def send_message(self, input_entry, output_text, port_combobox, speed_combobox, is_first=True):
        message = input_entry.get()
        if not message:
            return
        selected_port = port_combobox.get()
        connected_port = self.get_connected_port(selected_port)
        if connected_port == "No associated port":
            messagebox.showerror("Error", "There is no associated port for sending.")
            return
        speed = int(speed_combobox.get())
        self.logic.set_port_speed(selected_port, speed)
        self.logic.set_port_speed(connected_port, speed)
        bytes_in_portion = [0]

        def send_next_char(index, bytes_in_portion):
            if index < len(message):
                char = message[index]
                response = self.logic.send_and_receive_message(selected_port, connected_port, char)
                self.update_output(output_text, char, connected_port, response)
                bytes_in_portion[0] += 1
                self.update_status_window(selected_port, connected_port, bytes_in_portion[0])
                self.master.after(100, send_next_char, index + 1, bytes_in_portion)

        send_next_char(0, bytes_in_portion)

    def update_output(self, output_text, message, connected_port, response):
        output_text.config(state='normal')
        if response:
            output_text.insert(tk.END, f"Received: {response}\n")
        else:
            output_text.insert(tk.END, f"Unable to get response from {connected_port}.\n")
        output_text.config(state='disabled')

    def send_message_first(self, event=None):
        self.send_message(self.input_entry_send, self.left_output_text, self.send_port_combobox,
                          self.speed_combobox_send)

    def send_message_second(self, event=None):
        self.send_message(self.input_entry_receive, self.right_output_text, self.read_port_combobox,
                          self.speed_combobox_receive, is_first=False)

    def get_connected_port(self, port):
        return self.logic.port_pairs.get(port, "No associated port")

    def on_closing(self):
        self.logic.stop_read_thread()
        self.master.destroy()
